<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from codervent.com/rocker/color-version/pages-blank-page.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 15 Nov 2019 12:20:59 GMT -->
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>SMK Mahaputra <?php echo $__env->yieldPushContent('title'); ?></title>

  <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
  <div id="wrapper">
    <?php if(Auth()->user()->hasRole('admin')): ?>
      <?php echo $__env->make('includes.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(Auth()->user()->hasRole('staff')): ?>
      <?php echo $__env->make('includes.sidebar-staff', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif(Auth()->user()->hasRole('teacher')): ?>
      <?php echo $__env->make('includes.sidebar-teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
      <?php echo $__env->make('includes.sidebar-student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <div class="clearfix"></div>
	
      <div class="content-wrapper">
        <div class="container-fluid">
		      <?php echo $__env->yieldContent('content'); ?>
        </div> 
      </div>
    <!--Start Back To Top Button-->
      <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->	
	  
    <footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2018 Rocker Admin
        </div>
      </div>
    </footer>

  </div>

 <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
 
<!-- Mirrored from codervent.com/rocker/color-version/pages-blank-page.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 15 Nov 2019 12:20:59 GMT -->
</html>
<?php /**PATH E:\PPDB\ppdb\resources\views/layouts/master.blade.php ENDPATH**/ ?>