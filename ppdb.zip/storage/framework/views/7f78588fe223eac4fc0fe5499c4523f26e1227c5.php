

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="background-color: skyblue;"><?php echo e(__('Silahkan Verifikasi Email Anda')); ?></div>
                <div class="card-body">
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-primary alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>
                    <form id="resendVerification" action="/account/resend-verification" method="POST">
                        <?php echo csrf_field(); ?>
                        akun anda belum diverifikasi, harap cek email anda termasuk spam pada email anda <br>
                        <input type="submit" class="btn btn-info btn-round btn-sm waves-effect waves-light m-1" name="resend-verification" style="background-color: skyblue; float: right;" value="Kirim ulang email verifikasi" id="btnSubmit">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PPDB\ppdb\resources\views/auth/verify.blade.php ENDPATH**/ ?>