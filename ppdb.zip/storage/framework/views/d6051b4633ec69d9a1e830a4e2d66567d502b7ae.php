<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>SMK Mahaputra - Daftar</title>
  <!--favicon-->
  <link rel="icon" href="<?php echo e(asset('assets/images/logo.png')); ?>" type="image/x-icon">
  <!-- Bootstrap core CSS-->
  <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
  <!-- animate CSS-->
  <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" type="text/css" />
  <!-- Icons CSS-->
  <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css" />
  <!-- Custom Style-->
  <link href="<?php echo e(asset('assets/css/app-style.css')); ?>" rel="stylesheet" />

</head>

<body>
  <!-- Start wrapper-->
  <div id="wrapper">
    <div class="card border-primary border-top-sm border-bottom-sm card-authentication1 mx-auto my-5 animated bounceInDown">
      <div class="card-body">
        <div class="card-content p-2">
          <div class="text-center">
            <img style="height: 150px; width: 150px;" src="<?php echo e(asset('assets/images/mahaputra.jfif')); ?>">
          </div>
          <div class="card-title text-uppercase text-center py-3">Pilih Daftar</div>
            <center><div class="col-sm-9">
              <a href="<?php echo e(url('register-student')); ?>" class="btn btn-info btn-round btn-block waves-effect waves-light m-1">Siswa</a>
              </div>
              <div class="col-sm-9">
              <a href="<?php echo e(url('register-teacher')); ?>" class="btn btn-info btn-round btn-block waves-effect waves-light m-1">Guru</a>
              </div>
              <div class="col-sm-9">
              <a href="<?php echo e(url('register-staff')); ?>" class="btn btn-info btn-round btn-block waves-effect waves-light m-1">Staf</a>
              </div></center>
        </div>
      </div>
    </div>

    <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  </div>
  <!--wrapper-->

  <!-- Bootstrap core JavaScript-->
  <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

</body>

<!-- Mirrored from codervent.com/rocker/color-version/authentication-signin.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 15 Nov 2019 12:20:55 GMT -->

</html><?php /**PATH E:\PPDB\ppdb\resources\views/auth/register.blade.php ENDPATH**/ ?>