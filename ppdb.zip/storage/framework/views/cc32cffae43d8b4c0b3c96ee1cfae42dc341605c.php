

<?php $__env->startPush('title'); ?>
- Edit Kata Sandi
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
<meta name="description" content=""/>
<meta name="author" content=""/>
<title>Rocker - Bootstrap4  Admin Dashboard Template</title>
<!--favicon-->
<link rel="icon" href="<?php echo e(asset('assets/images/logo.png')); ?>" type="image/x-icon">
<!-- simplebar CSS-->
<link href="<?php echo e(asset('assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet"/>
<!-- Bootstrap core CSS-->
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
<!-- animate CSS-->
<link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" type="text/css"/>
<!-- Icons CSS-->
<link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css"/>
<!-- Sidebar CSS-->
<link href="<?php echo e(asset('assets/css/sidebar-menu.css')); ?>" rel="stylesheet"/>
<!-- Custom Style-->
<link href="<?php echo e(asset('assets/css/app-style.css')); ?>" rel="stylesheet"/>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row pt-2 pb-2">
  <div class="col-sm-9">
    <h4 class="page-title">Edit Kata Sandi</h4>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">SMK Mahaputra</a></li>
      <li class="breadcrumb-item active" aria-current="page">Edit Kata Sandi</li>
    </ol>
  </div>
</div>

<div class="row">
  <div class="col-lg-12">
    <div class="card">
     <div class="card-body">
       <div class="card-title">Edit Kata Sandi</div>
       <hr>
       <form method="POST" autocomplete="off" action="<?php echo e(url('account/profile/1/edit-password')); ?>" id="submitForm">
        <?php echo csrf_field(); ?>

        <div class="form-group row">
          <label for="input-4" class="col-sm-2 col-form-label">Kata Sandi Lama</label>
          <div class="col-sm-10">
            <input type="password" name="current_password" class="form-control form-control-rounded <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="input-4" placeholder="Masukan Kata Sandi Lama" value="<?php echo e(old('current_password')); ?>">
            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="input-5" class="col-sm-2 col-form-label">Kata Sandi Baru</label>
          <div class="col-sm-10">
            <input type="password" name="new_password" class="form-control form-control-rounded <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="input-5" placeholder="Masukan Kata Sandi Baru" value="<?php echo e(old('new_password')); ?>">
            <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="input-6" class="col-sm-2 col-form-label">Ulangi Kata Sandi</label>
          <div class="col-sm-10">
            <input type="password" name="confirm_new_password" class="form-control form-control-rounded <?php $__errorArgs = ['confirm_new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="input-6" placeholder="Ulangi Kata Sandi Baru" value="<?php echo e(old('confirm_new_password')); ?>">
            <?php $__errorArgs = ['confirm_new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="input-1" class="col-sm-2 col-form-label"></label>
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary shadow-primary px-5"><i class="icon-lock"></i> Perbarui</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
</div><!-- End Row-->

<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>

<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

<!-- simplebar js -->
<script src="<?php echo e(asset('assets/plugins/simplebar/js/simplebar.js')); ?>"></script>
<!-- waves effect js -->
<script src="<?php echo e(asset('assets/js/waves.js')); ?>"></script>
<!-- sidebar-menu js -->
<script src="<?php echo e(asset('assets/js/sidebar-menu.js')); ?>"></script>
<!-- Custom scripts -->
<script src="<?php echo e(asset('assets/js/app-script.js')); ?>"></script>

<script>
  $(document).ready(function() {
    $("#submitForm").submit(function(e) {
      $(this).find("button[type='submit']").prop('disabled', true);
      $("#btnSubmit").attr("disabled", true);
      return true;
    });      
  });

</script>
<?php $__env->stopPush(); ?>    
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PPDB\ppdb\resources\views/auth/edit-password.blade.php ENDPATH**/ ?>