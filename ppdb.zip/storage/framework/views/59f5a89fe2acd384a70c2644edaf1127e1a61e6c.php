

<?php $__env->startPush('title'); ?>
- Daftar Guru
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<!--favicon-->
<!--favicon-->
<link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">
<!-- simplebar CSS-->
<link href="<?php echo e(asset('assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
<!-- Bootstrap core CSS-->
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />
<!--Data Tables -->
<link href="<?php echo e(asset('assets/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<!-- animate CSS-->
<link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" type="text/css" />
<!-- Icons CSS-->
<link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css" />
<!-- Sidebar CSS-->
<link href="<?php echo e(asset('assets/css/sidebar-menu.css')); ?>" rel="stylesheet" />
<!-- Custom Style-->
<link href="<?php echo e(asset('assets/css/app-style.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row pt-2 pb-2">
  <div class="col-sm-9">
    <h4 class="page-title">Daftar Guru</h4>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">SMK Mahaputra</a></li>
      <li class="breadcrumb-item"><a href="javaScript:void();">Kelola Guru</a></li>
      <li class="breadcrumb-item active" aria-current="page">Daftar Guru</li>
    </ol>
  </div>
</div>

<div class="row">
  <div class="col-lg-12">
    <div class="card">
      <div class="card-header"><i class="fa fa-table"></i> Data Exporting</div>
      <div class="card-body">
        <div class="table-responsive">
          <?php if(Auth()->user()->hasRole('admin')): ?>
          <div class="container" style="margin-bottom: 10px; margin-left: -5px; margin-top: -4px;">
            <a href="<?php echo e(URL::to('/teacher/create')); ?>" data-toggle="tooltip" data-placement="top" title="TAMBAH GURU" type="button" class="btn btn-outline-primary waves-effect waves-light m-1"> <i class="zmdi zmdi-plus fa-lg"></i> </a>
          </div>
          <?php else: ?>
          <?php endif; ?>
          <table id="example" class="table table-bordered" style="width: 100%;">
            <thead>
              <tr>
                <th>NO</th>
                <th>NAMA</th>
                <th>NO GTK</th>
                <th>STATUS</th>
                <th>AKSI</th>
              </tr>
            </thead>
            <tbody>
            </tbody>
          </table>

        </div>
      </div>
    </div>
  </div>
</div><!-- End Row-->

<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

<?php $__env->startPush('scripts'); ?>
<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

<!-- simplebar js -->
<script src="<?php echo e(asset('assets/plugins/simplebar/js/simplebar.js')); ?>"></script>
<!-- waves effect js -->
<script src="<?php echo e(asset('assets/js/waves.js')); ?>"></script>
<!-- sidebar-menu js -->
<script src="<?php echo e(asset('assets/js/sidebar-menu.js')); ?>"></script>
<!-- Custom scripts -->
<script src="<?php echo e(asset('assets/js/app-script.js')); ?>"></script>

<!--Data Tables js-->
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datatable/js/buttons.colVis.min.js')); ?>"></script>


<script src="<?php echo e(asset('js_datatables/datatable.js')); ?>"></script>
<script>
  $(document).ready(function() {
    teacher()
  });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PPDB\ppdb\resources\views/teachers/list-teacher.blade.php ENDPATH**/ ?>