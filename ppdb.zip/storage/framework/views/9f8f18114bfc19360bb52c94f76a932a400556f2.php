<center>
    <h1><b>Halo <?php echo e($users->usr_name); ?></b></h1> <br>
    <strong> EXAMPLE BODY BOLD FORGOT PASSWORD </strong> <br>
    Silahkan klik link di bawah ini untuk mengubah password anda <br>
    <a href="<?php echo e(url('/account/'.$resetPassword->pwr_token.'/forgot-password')); ?>"> CLICK HERE </a> <br><br><br>
</center>
Thanks, <br>
SMKS MAHAPUTRA CERDAS UTAMA<?php /**PATH E:\PPDB\ppdb\resources\views/email-password.blade.php ENDPATH**/ ?>