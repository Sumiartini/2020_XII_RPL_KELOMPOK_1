<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>SMK Mahaputra - Formulir Siswa</title>
    <!--favicon-->
    <link rel="icon" href="<?php echo e(asset('assets/images/logo.png')); ?>" type="image/x-icon">
    <!-- simplebar CSS-->
    <link href="<?php echo e(asset('assets/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet">
    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- animate CSS-->
    <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" type="text/css">
    <!--Bootstrap Datepicker-->
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- Icons CSS-->
    <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">
    <!-- Sidebar CSS-->
    <link href="<?php echo e(asset('assets/css/sidebar-menu.css')); ?>" rel="stylesheet">
    <!-- Custom Style-->
    <link href="<?php echo e(asset('assets/css/app-style.css')); ?>" rel="stylesheet">
    <style>
        footer {
            color: #272727;
            text-align: center;
            padding: 12px 30px;
            margin-bottom: -10px;
            margin-top: 10px;
            border-top: 1px solid rgb(223, 223, 255);
            -webkit-transition: all 0.3s ease;
            -moz-transition: all 0.3s ease;
            -o-transition: all 0.3s ease;
            transition: all 0.3s ease;
        }
    </style>
</head>

<body>
    <header class="navbar navbar-expand-md navbar-light bg-white shadow-sm fixed-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('assets/images/mahaputra.jfif')); ?>" style="width: 50px;" height="50px;"> <?php echo e(config('app.name', 'Laravel')); ?>

            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">
                </ul>
                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">

                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(__('Register')); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(url('register-student')); ?>">Siswa</a>
                            <a class="dropdown-item" href="<?php echo e(url('register-teacher')); ?>">Guru</a>
                            <a class="dropdown-item" href="<?php echo e(url('register-staff')); ?>">Staff TU</a>
                        </div>
                    </li>
                    <?php endif; ?>
                    <?php else: ?>


                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->usr_name); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</header><br>

<div class="container-fluid" style="margin-top: 80px">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <form id="submitForm" autocomplete="off" method="POST" action="<?php echo e(url('student-registration')); ?>" novalidate="novalidate" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h4 class="form-header text-uppercase">
                            <i class="  "></i>
                            Data Calon Siswa
                        </h4>

                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label> Nama Lengkap <span style="color:red"> *</span></label>
                                <input type="text" class="form-control form-control-rounded <?php $__errorArgs = ['stu_candidate_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="stu_candidate_name" placeholder="Masukan Nama Lengkap" value="<?php echo e(old('stu_candidate_name')); ?>">
                                <?php $__errorArgs = ['stu_candidate_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <p style="font-size: 12px;"> Sesuaikan dengan nama di ijazah SD/SMP </p>
                            </div>


                            <div class="col-sm-4">
                                <label> Jenis Kelamin <span style="color:red"> *</span></label>

                                <select name="usr_gender" class="form-control form-control-rounded <?php $__errorArgs = ['usr_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('usr_gender')); ?>">
                                    <option disabled="" selected=""> Pilih </option>
                                    <option value="Laki-laki"> Laki Laki </option>
                                    <option value="Perempuan"> Perempuan </option>
                                </select>
                                <?php $__errorArgs = ['usr_gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                            <div class="col-sm-4">
                                <label> NISN <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" class="form-control form-control-rounded <?php $__errorArgs = ['stu_nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="stu_nisn" placeholder="Masukan Nomor NISN" value="<?php echo e(old('stu_nisn')); ?>">
                                <?php $__errorArgs = ['stu_nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>


                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label> Nomor Telepon<span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" class="form-control form-control-rounded <?php $__errorArgs = ['usr_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="usr_phone_number" placeholder="Masukan Nomor Telepon" value="<?php echo e(old('usr_phone_number')); ?>">
                                <?php $__errorArgs = ['usr_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> No. WhatsApp <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" class="form-control form-control-rounded <?php $__errorArgs = ['usr_whatsapp_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="usr_whatsapp_number" placeholder="Masukan No. WhatsApp" value="<?php echo e(old('usr_whatsapp_number')); ?>">
                                <?php $__errorArgs = ['usr_whatsapp_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Tempat Lahir <span style="color:red"> *</span></label>
                                <input type="text" name="usr_place_of_birth" class="form-control form-control-rounded <?php $__errorArgs = ['usr_place_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Tempat Lahir" value="<?php echo e(old('usr_place_of_birth')); ?>">
                                <?php $__errorArgs = ['usr_place_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <div class="col-sm-4">
                                <label> Tanggal Lahir <span style="color:red"> *</span></label>
                                <input type="text" name="usr_date_of_birth" id="autoclose-datepicker" class="form-control form-control-rounded <?php $__errorArgs = ['usr_date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Tanggal-Bulan-Tahun" value="<?php echo e(old('usr_date_of_birth')); ?>">
                                <?php $__errorArgs = ['usr_date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> No Registrasi Akta Lahir </label>
                                <input type="text" class="form-control form-control-rounded" name="personal[birth_certificate_registration_no]" placeholder="Masukan No Registrasi Akta Lahir" value="<?php echo e(old('personal.birth_certificate_registration_no')); ?>">
                                <?php $__errorArgs = ['personal.birth_certificate_registration_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Tinggal Bersama <span style="color:red"> *</span></label>
                                <select class="form-control form-control-rounded <?php $__errorArgs = ['personal.living_together'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="personal[living_together]" id="basic-select" value="<?php echo e(old('personal.living_together')); ?>">
                                    <option disabled="" selected=""> Pilih </option>
                                    <option value="Orang Tua"> Orang Tua </option>
                                    <option value="Wali"> Wali </option>
                                    <option value="Kos"> Kos </option>
                                    <option value="Asrama"> Asrama </option>
                                    <option value="Panti Asuhan"> Panti Asuhan </option>
                                    <option value="Pesantren"> Pesantren </option>
                                </select>
                                <?php $__errorArgs = ['personal.living_together'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>


                        <div class="form-group row">
                            <div class="col-sm-4">
                                <label> Asal Sekolah <span style="color:red"> *</span></label>
                                <input type="text" name="stu_school_origin" class="form-control form-control-rounded <?php $__errorArgs = ['stu_school_origin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" placeholder="Masukan Asal Sekolah" value="<?php echo e(old('stu_school_origin')); ?>">
                                <?php $__errorArgs = ['stu_school_origin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Jurusan yang diminati <span style="color:red"> *</span></label>
                                <select class="form-control form-control-rounded <?php $__errorArgs = ['stu_major_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="stu_major_id" id="basic-select" value="<?php echo e(old('stu_major_id')); ?>">

                                    <option disabled="" selected=""> Pilih </option>
                                    <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($major->mjr_id); ?>"><?php echo e($major->mjr_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                                <?php $__errorArgs = ['stu_major_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="col-sm-2">
                                <label> Anak Ke</label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="personal[child]" class="form-control form-control-rounded <?php $__errorArgs = ['personal.child'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Anak Ke" value="<?php echo e(old('personal.child')); ?>">
                                <?php $__errorArgs = ['personal.child'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-2">
                                <label> Agama <span style="color:red"> *</span></label>
                                <select class="form-control form-control-rounded <?php $__errorArgs = ['usr_religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="usr_religion" id="basic-select" value="<?php echo e(old('usr_religion')); ?>">
                                    <option disabled="" selected=""> Pilih </option>
                                    <option value="Islam"> Islam </option>
                                    <option value="Protestan"> Protestan </option>
                                    <option value="Katolik"> Katolik </option>
                                    <option value="Hindu"> Hindu </option>
                                    <option value="Budha"> Budha </option>
                                    <option value="Khonghucu"> Khonghucu </option>
                                </select>
                                <?php $__errorArgs = ['usr_religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>

                        <label>Foto calon siswa<span style="color:red"> *</span></label>
                        <div class="form-group row">

                            <div class="col-sm-4">
                                <img src="#" class="img-thumbnail" id="tampil_picture" style="object-fit: cover; height: 200px; width: 200px"/> 
                                <input type="file" name="usr_profile_picture" id="preview_gambar" class="img-thumbnail <?php $__errorArgs = ['isr_profile_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/x-png,image/gif,image/jpeg" style="display:none" onchange="document.getElementById('usr_profile_picture').value=this.value" /><br>
           
                                <button type="button" id="usr_profile_picture" class="btn btn-outline-primary btn-sm waves-effect waves-light m-2" onclick="document.getElementById('preview_gambar').click()"> Pilih Gambar </button>
                                <?php $__errorArgs = ['usr_profile_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <p>
                                        <strong style="font-size: 80%;color: #dc3545;"><?php echo e($message); ?></strong>
                                   </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>


                        <h4 class="form-header text-uppercase">
                            <i class=""></i>
                            Data Ayah
                        </h4>

                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label> Nama Ayah Kandung <span style="color:red"> *</span></label>
                                <input type="text" name="father_data[name]" class="form-control form-control-rounded <?php $__errorArgs = ['father_data.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nama Lengkap" value="<?php echo e(old('father_data.name')); ?>">
                                <?php $__errorArgs = ['father_data.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Nomor Identitas Kependudukan (NIK) <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="father_data[nik]" class="form-control form-control-rounded <?php $__errorArgs = ['father_data.nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nomor NIK" value="<?php echo e(old('father_data.nik')); ?>">
                                <?php $__errorArgs = ['father_data.nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Tahun Lahir <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" class="form-control form-control-rounded <?php $__errorArgs = ['father_data.year_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="father_data[year_of_birth]" id="basic-select" placeholder="Masukan Tahun Lahir" value="<?php echo e(old('father_data.year_of_birth')); ?>">
                                    
                                <?php $__errorArgs = ['father_data.year_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-4">
                                <label>Pendidikan Terakhir<span style="color:red"> *</span></label>
                                <select name="father_data[education]" class="form-control form-control-rounded <?php $__errorArgs = ['father_data.education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('father_data.education')); ?>">
                                    <option disabled="" selected=""> Pilih </option>
                                    <option value="SD - Sederajat"> SD - Sederajat </option>
                                    <option value="SMP - Sederajat"> SMP - Sederajat </option>
                                    <option value="SMA - Sederajat"> SMA - Sederajat </option>
                                    <option value="KULIAH - Sederajat"> KULIAH - Sederajat </option>
                                </select>
                                <?php $__errorArgs = ['father_data.education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                            <div class="col-sm-4">
                                <label>Pekerjaan<span style="color:red"> *</span></label>
                                <select name="father_data[profession]" class="form-control form-control-rounded <?php $__errorArgs = ['father_data.profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('father_data.profession')); ?>">
                                    <option disabled="" selected="">Pilih</option>
                                    <option value="Buruh"> Buruh </option>
                                    <option value="Wirausaha"> Wirausaha </option>
                                    <option value="Wiraswasta"> Wiraswasta </option>
                                </select>
                                <?php $__errorArgs = ['father_data.profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="col-sm-4">
                                <label>Pendapatan Perbulan</label>
                                <select name="father_data[monthly_income]" class="form-control form-control-rounded <?php $__errorArgs = ['father_data.monthly_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('father_data.monthly_income')); ?>">
                                    <option value="" selected="">Pilih</option>
                                    <option value="kurang dari Rp. 500.000"> kurang dari Rp. 500.000 </option>
                                    <option value="Rp. 500.000 - Rp.1.000.000"> Rp. 500.000 - Rp.1.000.000 </option> 
                                    <option value="Rp. 1.000.000 - Rp. 2.000.000"> Rp. 1.000.000 - Rp. 2.000.000 </option>
                                    <option value="Rp. 2.000.000 - Rp. 3.000.000"> Rp. 2.000.000 - Rp. 3.000.000 </option>
                                    <option value="Rp. 3.000.000 - Rp. 4.000.000"> Rp. 3.000.000 - Rp. 4.000.000 </option>
                                    <option value="lebih dari Rp. 4.000.000"> lebih dari Rp. 4.000.000 </option>
                                </select>
                               
                            </div>
                        </div>

                        <div class="form-group row">


                                
                            <div class="col-sm-4">
                                <label> Nomor Telepon <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="father_data[phone_number]" class="form-control form-control-rounded <?php $__errorArgs = ['father_data.phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nomor Telepon" value="<?php echo e(old('father_data.phone_number')); ?>">
                                <?php $__errorArgs = ['father_data.phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="col-sm-4">
                                <label> Disabilitas <span style="color:red"> *</span></label> <br>

                                <div class="radio icheck-info icheck-inline">
                                    <input type="radio" id="disability_father1" value="Ya" name="father_data[disability]">
                                    <label for="disability_father1"> Ya </label>
                                </div>
                                <div class="radio icheck-info icheck-inline">
                                    <input type="radio" checked="" id="disability_father2" value="Tidak" name="father_data[disability]">
                                    <label for="disability_father2"> Tidak </label>
                                </div>
                            </div>
                        </div>

                        <h4 class="form-header text-uppercase">
                            <i class=""></i>
                            Data Ibu
                        </h4>

                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label> Nama Ibu Kandung <span style="color:red"> *</span></label>
                                <input type="text" name="mother_data[name]" class="form-control form-control-rounded <?php $__errorArgs = ['mother_data.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nama Lengkap" value="<?php echo e(old('mother_data.name')); ?>">
                                <?php $__errorArgs = ['mother_data.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Nomor Identitas Kependudukan (NIK) <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="mother_data[nik]" class="form-control form-control-rounded <?php $__errorArgs = ['mother_data.nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nomor NIK" value="<?php echo e(old('mother_data.nik')); ?>">
                                <?php $__errorArgs = ['mother_data.nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Tahun Lahir <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="mother_data[year_of_birth]" class="form-control form-control-rounded <?php $__errorArgs = ['mother_data.year_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" placeholder="Masukan Tahun Lahir" value="<?php echo e(old('mother_data.year_of_birth')); ?>">
                                    
                                <?php $__errorArgs = ['mother_data.year_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label>Pendidikan Terakhir<span style="color:red"> *</span></label>
                                <select name="mother_data[education]" class="form-control form-control-rounded <?php $__errorArgs = ['mother_data.education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('mother_data.education')); ?>">
                                    <option disabled="" selected="">Pilih</option>
                                    <option value="SD - Sederajat"> SD - Sederajat </option>
                                    <option value="SMP - Sederajat"> SMP - Sederajat </option>
                                    <option value="SMA - Sederajat"> SMA - Sederajat </option>
                                    <option value="KULIAH - Sederajat"> KULIAH - Sederajat </option>
                                </select>
                                <?php $__errorArgs = ['mother_data.education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-4">
                                <label> Pekerjaan <span style="color:red"> *</span></label>

                                <select name="mother_data[profession]" class="form-control form-control-rounded <?php $__errorArgs = ['mother_data.profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('mother_data.profession')); ?>">
                                    <option disabled="" selected=""> Pilih </option>
                                    <option value="Buruh"> Buruh </option>
                                    <option value="Wirausaha"> Wirausaha </option>
                                    <option value="Wiraswasta"> Wiraswasta </option>
                                    <option value="Ibu Rumah Tangga"> Ibu Rumah Tangga </option>
                                </select>
                                <?php $__errorArgs = ['mother_data.profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                            <div class="col-sm-4">
                                <label>Pendapatan Perbulan</label>
                                <select name="mother_data[monthly_income]" class="form-control form-control-rounded <?php $__errorArgs = ['mother_data.monthly_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('mother_data.monthly_income')); ?>">
                                    <option value="" selected="">Pilih</option>
                                    <option value="kurang dari Rp. 500.000"> kurang dari Rp. 500.000 </option>
                                    <option value="Rp. 500.000 - Rp.1.000.000"> Rp. 500.000 - Rp.1.000.000 </option> 
                                    <option value="Rp. 1.000.000 - Rp. 2.000.000"> Rp. 1.000.000 - Rp. 2.000.000 </option>
                                    <option value="Rp. 2.000.000 - Rp. 3.000.000"> Rp. 2.000.000 - Rp. 3.000.000 </option>
                                    <option value="Rp. 3.000.000 - Rp. 4.000.000"> Rp. 3.000.000 - Rp. 4.000.000 </option>
                                    <option value="lebih dari Rp. 4.000.000"> lebih dari Rp. 4.000.000 </option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-4">
                                <label> Nomor Telepon <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="mother_data[phone_number]" class="form-control form-control-rounded <?php $__errorArgs = ['mother_data.phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nomor Telepon" value="<?php echo e(old('mother_data.phone_number')); ?>">
                                <?php $__errorArgs = ['mother_data.phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Disabilitas <span style="color:red"> *</span></label> <br>

                                <div class="radio icheck-info icheck-inline">
                                    <input type="radio" id="disability_mother1" value="Ya" name="mother_data[disability]">
                                    <label for="disability_mother1"> Ya </label>
                                </div>

                                <div class="radio icheck-info icheck-inline">
                                    <input type="radio" checked="" id="disability_mother2" value="Tidak" name="mother_data[disability]">
                                    <label for="disability_mother2"> Tidak </label>

                                </div>
                            </div>
                        </div>

                        <h4 class="form-header text-uppercase">
                            <i class=""></i>
                            Data Wali
                        </h4>

                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label> Nama Lengkap </label>
                                <input type="text" name="guardian_data[name]" class="form-control form-control-rounded <?php $__errorArgs = ['guardian_data[name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="firstname" placeholder="Masukan Nama Lengkap" value="<?php echo e(old('guardian_data[name]')); ?>">
                                <?php $__errorArgs = ['guardian_data[name]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Nomor Identitas Kependudukan (NIK) </label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="guardian_data[nik]" class="form-control form-control-rounded <?php $__errorArgs = ['guardian_data.nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="firstname" placeholder="Masukan Nomor NIK" value="<?php echo e(old('guardian_data.nik')); ?>">
                                <?php $__errorArgs = ['guardian_data.nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Tahun Lahir </label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="guardian_data[year_of_birth]" class="form-control form-control-rounded <?php $__errorArgs = ['guardian_data.year_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" placeholder="Masukan Tahun Lahir" value="<?php echo e(old('guardian_data.year_of_birth')); ?>">
                                
                                <?php $__errorArgs = ['guardian_data.year_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label>Pendidikan Terakhir</label>
                                <select name="guardian_data[education]" class="form-control form-control-rounded <?php $__errorArgs = ['guardian_data.education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('guardian_data.education')); ?>"> 
                                    <option value="" selected="">Pilih</option>
                                    <option value="SD - Sederajat"> SD - Sederajat </option>
                                    <option value="SMP - Sederajat"> SMP - Sederajat </option>
                                    <option value="SMA - Sederajat"> SMA - Sederajat </option>
                                    <option value="KULIAH - Sederajat"> KULIAH - Sederajat </option>
                                </select>
                                <?php $__errorArgs = ['guardian_data.education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Pekerjaan </label>
                                <select name="guardian_data[profession]" class="form-control form-control-rounded <?php $__errorArgs = ['guardian_data.profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('guardian_data.profession')); ?>">
                                    <option value="" selected=""> Pilih </option>
                                    <option value="Buruh"> Buruh </option>
                                    <option value="Wirausaha"> Wirausaha </option>
                                    <option value="Wiraswasta"> Wiraswasta </option>
                                    <option value="Ibu Rumah Tangga"> Ibu Rumah Tangga </option>
                                </select>
                                <?php $__errorArgs = ['guardian_data.profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-4">
                                <label>Pendapatan Perbulan</label>
                                <select name="guardian_data[monthly_income]" class="form-control form-control-rounded <?php $__errorArgs = ['guardian_data.monthly_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('guardian_data.monthly_income')); ?>">
                                    <option value="" selected="">Pilih</option>
                                    <option value="" value="kurang dari Rp. 500.000"> kurang dari Rp. 500.000 </option>
                                    <option value="Rp. 500.000 - Rp.1.000.000"> Rp. 500.000 - Rp.1.000.000 </option> 
                                    <option value="Rp. 1.000.000 - Rp. 2.000.000"> Rp. 1.000.000 - Rp. 2.000.000 </option>
                                    <option value="Rp. 2.000.000 - Rp. 3.000.000"> Rp. 2.000.000 - Rp. 3.000.000 </option>
                                    <option value="Rp. 3.000.000 - Rp. 4.000.000"> Rp. 3.000.000 - Rp. 4.000.000 </option>
                                    <option value="lebih dari Rp. 4.000.000"> lebih dari Rp. 4.000.000 </option>
                                </select>
                                <?php $__errorArgs = ['guardian_data.monthly_income'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-sm-4">
                                <label> Nomor Telepon</label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="guardian_data[phone_number]" class="form-control form-control-rounded <?php $__errorArgs = ['guardian_data.phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nomor Telepon" value="<?php echo e(old('guardian_data.phone_number')); ?>">
                                <?php $__errorArgs = ['guardian_data.phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Disabilitas </label> <br>

                                <div class="radio icheck-info icheck-inline">
                                    <input type="radio" id="disability_guardian1" value="Ya" name="guardian_data[disability]">
                                    <label for="disability_guardian1"> Ya </label>
                                </div>
                                <div class="radio icheck-info icheck-inline">
                                    <input type="radio" checked="" value="Tidak" id="disability_guardian2" name="guardian_data[disability]">
                                    <label for="disability_guardian2"> Tidak </label>

                                </div>
                            </div>
                        </div>

                        <h4 class="form-header text-uppercase">
                            <i class=""></i>
                           Data Persuratan
                        </h4>

                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label> Provinsi <span style="color:red"> *</span></label>
                                <input type="text" name="prv_name" class="form-control form-control-rounded <?php $__errorArgs = ['prv_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" placeholder="Masukan Provinsi" value="<?php echo e(old('prv_name')); ?>">
                                <?php $__errorArgs = ['prv_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-4">
                                <label> Kota/Kabupaten <span style="color:red"> *</span></label>
                                <input type="text" name="cit_name" class="form-control form-control-rounded <?php $__errorArgs = ['cit_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" placeholder="Masukan Kota/kabupaten" value="<?php echo e(old('cit_name')); ?>">
                                <?php $__errorArgs = ['cit_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-4">
                                <label>Kecamatan<span style="color:red"> *</span></label>
                                <input type="text" name="dst_name" class="form-control form-control-rounded <?php $__errorArgs = ['dst_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" placeholder="Masukan Kecamatan" value="<?php echo e(old('dst_name')); ?>">
                                <?php $__errorArgs = ['dst_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label> Alamat <span style="color:red"> *</span></label>
                                <input type="text" name="usr_address" class="form-control form-control-rounded <?php $__errorArgs = ['usr_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Alamat" value="<?php echo e(old('usr_address')); ?>">
                                <?php $__errorArgs = ['usr_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-2">
                                <label> RT <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="usr_rt" class="form-control form-control-rounded <?php $__errorArgs = ['usr_rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nomor RT" value="<?php echo e(old('usr_rt')); ?>">
                                <?php $__errorArgs = ['usr_rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-2">
                                <label> RW <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="usr_rw" class="form-control form-control-rounded <?php $__errorArgs = ['usr_rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nomor RW" value="<?php echo e(old('usr_rw')); ?>">
                                <?php $__errorArgs = ['usr_rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-4">
                                 <label>Desa/Kelurahan<span style="color:red"> *</span></label>
                               <input type="text" name="usr_rural_name" class="form-control form-control-rounded <?php $__errorArgs = ['usr_rural_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Desa/Kelularah" value="<?php echo e(old('usr_rural_name')); ?>">
                                <?php $__errorArgs = ['usr_rural_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
 
                        </div>


                         <div class="form-group row">
                        

                                
                            <div class="col-sm-4">
                                <label> Kode Pos <span style="color:red"> *</span></label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="usr_postal_code" class="form-control form-control-rounded <?php $__errorArgs = ['usr_postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Kode Pos" value="<?php echo e(old('usr_postal_code')); ?>">
                                <?php $__errorArgs = ['usr_postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Telepon Rumah </label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="contact[landline_number]" class="form-control form-control-rounded <?php $__errorArgs = ['contact.landline_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Nomor Telepon Rumah" value="<?php echo e(old('contact.landline_number')); ?>">
                                <?php $__errorArgs = ['contact.landline_number]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-sm-4">
                                <label> Email <span style="color:red"> *</span> </label>
                                <input type="text" name="contact[email]" class="form-control form-control-rounded <?php $__errorArgs = ['contact.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukan Alamat Email" value="<?php echo e(old('contact.email')); ?>">
                                 <?php $__errorArgs = ['contact.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <p style="font-size: 12px;"  > Email anggota keluarga yang aktif </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                        </div>
                    
                        <h4 class="form-header text-uppercase">
                            <i class=""></i>
                            Prestasi
                        </h4>
                        <div class="form-group row">

                            <div class="col-sm-4">
                                <label> Jenis </label>

                                <div class="radio icheck-info">
                                    <input type="radio" id="achievementType1" value="Sains" name="achievement[type]">
                                    <label for="achievementType1"> Sains </label>
                                </div>
                                <div class="radio icheck-info">
                                    <input type="radio" id="achievementType2" value="Seni" name="achievement[type]">
                                    <label for="achievementType2"> Seni </label>
                                </div>
                                <div class="radio icheck-info">
                                    <input type="radio" id="achievementType3" value="Olahraga" name="achievement[type]">
                                    <label for="achievementType3"> Olahraga </label>
                                </div>
                                <div class="radio icheck-info">
                                    <input type="radio" checked="" id="achievementType4" value="" name="achievement[type]">
                                    <label for="achievementType4"> Tidak ada </label>
                                </div>
                            </div>

                             <div class="col-sm-4">
                                <label> Tingkat</label>

                                <div class="radio icheck-info">
                                    <input type="radio" id="achievementLevel1" value="Sekolah" name="achievement[achievement_level]">
                                    <label for="achievementLevel1"> Sekolah </label>
                                </div>
                                <div class="radio icheck-info">
                                    <input type="radio" id="achievementLevel2" value="Kecamatan" name="achievement[achievement_level]">
                                    <label for="achievementLevel2"> Kecamatan </label>
                                </div>
                                <div class="radio icheck-info">
                                    <input type="radio" id="achievementLevel3" value="Kabupaten" name="achievement[achievement_level]">
                                    <label for="achievementLevel3"> Kabupaten </label>
                                </div>
                                <div class="radio icheck-info">
                                    <input type="radio" checked="" id="achievementLevel4" value="Provinsi" name="achievement[achievement_level]">
                                    <label for="achievementLevel4"> Provinsi </label>
                                </div>

                                 <div class="radio icheck-info">
                                    <input type="radio" id="achievementLevel5" value="Nasional" name="achievement[achievement_level]">
                                    <label for="achievementLevel5"> Nasional </label>
                                </div>

                                 <div class="radio icheck-info">
                                    <input type="radio" id="achievementLevel6" value="Internasioanl" name="achievement[achievement_level]">
                                    <label for="achievementLevel6"> Internasional </label>
                                </div>

                                 <div class="radio icheck-info">
                                    <input type="radio" checked="" id="achievementLevel7" value="" name="achievement[achievement_level]">
                                    <label for="achievementLevel7"> Tidak ada </label>
                                </div>
                                
                            </div>

                            <div class="col-sm-4">
                                <div>
                                <label> Nama Prestasi </label>
                                <input type="text" name="achievement[achievement_name]" class="form-control form-control-rounded" placeholder="Masukan Nama Prestasi" value="<?php echo e(old('achievement.achievement_name')); ?>">
                                </div>

                                <div>
                                <label> Tahun </label>
                                <input oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" type="text" name="achievement[year]" class="form-control form-control-rounded" placeholder="Masukan Tahun" value="<?php echo e(old('achievement.year')); ?>">
                                </div>
                                
                                <div>
                                <label> Penyelenggara </label>
                                <input type="text" name="achievement[organizer]" class="form-control form-control-rounded" placeholder="Masukan Nama Penyelenggara Kegiatan" value="<?php echo e(old('achievement.organizer')); ?>">

                               </div>
                            </div>
                        </div>

                        <h4 class="form-header text-uppercase">
                            <i class=""></i>
                            Lainnya
                        </h4>
                        <div class="form-group row">
                            <div class="col-sm-4">
                                <label>Rekomendasi dari</label>
                                <select name="other[recomended_from]" class="form-control form-control-rounded <?php $__errorArgs = ['other.recomended_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="basic-select" value="<?php echo e(old('other.recomended_from')); ?>">
                                    <option value="" selected=""> Pilih </option>
                                    <option value="Iklan"> Iklan (Poster, Banner, Dll) </option>
                                    <option value="Sosmed"> Sosmed (IG, FB, YT, dll) </option>
                                    <option value="Saudara"> Saudara </option>
                                    <option value="Tetangga"> Tetangga </option>
                                    <option value="Siswa/i Mahaputra"> Siswa/i Mahaputra </option>
                                    
                                </select>
                                <?php $__errorArgs = [''];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>

                        <div class="form-footer">
                            <button type="reset" class="btn btn-danger"><i class="fa fa-times"></i> BATAL </button>
                            <button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> SIMPAN </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<footer>
    <div class="container">
        <div class="text-center">
            Copyright © 2018 Rocker Admin
        </div>
    </div>
</footer>


<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->

<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

<!-- simplebar js -->
<script src="<?php echo e(asset('assets/plugins/simplebar/js/simplebar.js')); ?>"></script>
<!-- waves effect js -->
<script src="<?php echo e(asset('assets/js/waves.js')); ?>"></script>
<!-- sidebar-menu js -->
<script src="<?php echo e(asset('assets/js/sidebar-menu.js')); ?>"></script>
<!-- Custom scripts -->
<script src="<?php echo e(asset('assets/js/app-script.js')); ?>"></script>

<!--Form Validatin Script-->
<script src="<?php echo e(asset('assets/plugins/jquery-validation/js/jquery.validate.min.js')); ?>"></script>
<script>
    $().ready(function() {

        $("#personal-info").validate();

            // validate signup form on keyup and submit
            $("#signupForm").validate({
                rules: {
                    firstname: "required",
                    lastname: "required",
                    username: {
                        required: true,
                        minlength: 2
                    },
                    password: {
                        required: true,
                        minlength: 5
                    },
                    confirm_password: {
                        required: true,
                        minlength: 5,
                        equalTo: "#password"
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    contactnumber: {
                        required: true,
                        minlength: 10
                    },
                    topic: {
                        required: "#newsletter:checked",
                        minlength: 2
                    },
                    agree: "required"
                },
                messages: {
                    firstname: "Please enter your firstname",
                    lastname: "Please enter your lastname",
                    username: {
                        required: "Please enter a username",
                        minlength: "Your username must consist of at least 2 characters"
                    },
                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 5 characters long"
                    },
                    confirm_password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 5 characters long",
                        equalTo: "Please enter the same password as above"
                    },
                    email: "Please enter a valid email address",
                    contactnumber: "Please enter your 10 digit number",
                    agree: "Please accept our policy",
                    topic: "Please select at least 2 topics"
                }
            });

        });
    function bacaGambar(input) {
     if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
          $('#tampil_picture').attr('src', e.target.result);
      }

      reader.readAsDataURL(input.files[0]);
  }
}
$("#preview_gambar").change(function(){
 bacaGambar(this);
});
</script>

<script>
    $(document).ready(function() {
        $("#submitForm").submit(function(e) {
            $(this).find("button[type='submit']").prop('disabled', true);
            $("#btnSubmit").attr("disabled", true);
            return true;
        });      
    });

</script>

<!--Bootstrap Datepicker Js-->
<script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<script>
    $('#default-datepicker').datepicker({
        todayHighlight: true
    });
    $('#autoclose-datepicker').datepicker({
        autoclose: true,
        todayHighlight: true,
        format: "yyyy-mm-dd"
    });

    $('#inline-datepicker').datepicker({
        todayHighlight: true
    });

    $('#dateragne-picker .input-daterange').datepicker({});
</script>


</body>

</html><?php /**PATH E:\PPDB\ppdb\resources\views/students/registration-student.blade.php ENDPATH**/ ?>